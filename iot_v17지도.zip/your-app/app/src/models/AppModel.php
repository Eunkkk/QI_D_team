<?php
namespace App\Model;

final class AppModel extends BaseModel
{

    // public function delete_from_temp_user_table($nonce)
    // {
    //     $sql = "DELETE FROM Temp_user where auth_code = ?";
    //     $sth = $this->db->prepare($sql);
    //     $sth->execute(array($nonce));
    //     $results = $sth->rowCount();
    //     return $results;
    // }

    
}
