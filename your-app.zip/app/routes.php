<?php
// Routes

$app->get('/', 'App\Controller\HomeController:dispatch')
    ->setName('homepage');


//============================================================================================
// rending page
//============================================================================================

$app->get('/user/signin', 'App\Controller\UserController:sign_in_page')
    ->setName('usersignin');

$app->get('/user/signup', 'App\Controller\UserController:sign_up_page')
    ->setName('usersignup');

$app->get('/user/pwchange', 'App\Controller\UserController:pw_change_page')
    ->setName('userpwchange');

$app->get('/user/fpwchange', 'App\Controller\UserController:forgotton_pw_change_page')
    ->setName('userforgottenpwchange');

$app->get('/user/idcancellation', 'App\Controller\UserController:ID_cancellation_page')
    ->setName('useridcancellation');


/////////////////////////////밑은 테스트용 
$app->post('/test', 'App\Controller\UserController:json_test')
    ->setName('useridcancellation');

//============================================================================================
// API
//============================================================================================

$app->get('/user/signin/activate/{nonce}', 'App\Controller\UserController:account_activate')
    ->setName('useraccountactivate');

$app->post('/user/signin/request', 'App\Controller\UserController:sign_in_request')
    ->setName('usersigninrequest');

$app->post('/user/signup/request', 'App\Controller\UserController:sign_up_request')
    ->setName('usersignuprequest');

$app->get('/user/signout/request', 'App\Controller\UserController:sign_out/sign_out_request')
    ->setName('usersignout');

$app->post('/user/duplicatecheck', 'App\Controller\UserController:duplicate_check')
    ->setName('userduplicatecheck');

//===================================================================================================================

$app->post('/sensor/register', 'App\Controller\SensorController:sensor_register')
    ->setName('sensorregister');

$app->post('/sensor/association', 'App\Controller\SensorController:sensor_association')
    ->setName('sensorassociation');

$app->post('/sensor/deregister', 'App\Controller\SensorController:sensor_deregister')
    ->setName('sensorderegister');

$app->post('/sensor/deassociation', 'App\Controller\SensorController:sensor_deassociation')
    ->setName('sensordeassociation');

//===================================================================================================================
