<?php

namespace App\Controller;

use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Message\ResponseInterface as Response;

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

final class UserController extends BaseController
{
  protected $logger;
  protected $UserModel;
  protected $view;

  public function __construct($logger, $UserModel, $view)
  {
    $this->logger = $logger;
    $this->UserModel = $UserModel;
    $this->view = $view;
  }

  //============================================================================================
  // rending page
  //============================================================================================

  public function sign_up_page(Request $request, Response $response, $args)
  {
    $this->view->render($response, 'signup.twig');
    return $response;
  }

  public function sign_in_page(Request $request, Response $response, $args)
  {
    $this->view->render($response, 'signin.twig');
    return $response;
  }

  public function pw_change_page(Request $request, Response $response, $args)
  {
    $this->view->render($response, 'pwchange.twig');
    return $response;
  }

  public function forgotton_pw_change_page(Request $request, Response $response, $args)
  {
    $this->view->render($response, 'fpwchange.twig');
    return $response;
  }

  public function ID_cancellation_page(Request $request, Response $response, $args)
  {
    $this->view->render($response, 'IDCancellation.twig');
    return $response;
  }

  //============================================================================================
  // API
  //============================================================================================

  public function sign_up_request(Request $request, Response $response, $args)
  {
    try {
      $user['e_mail'] =  $_POST['e_mail'];
      $user['first_name'] =  $_POST['first_name'];
      $user['last_name'] =  $_POST['last_name'];
      $user['birth_date'] =  $_POST['birth_date'];
      $user['timestamp'] =  date("Y-m-d H:i:s");
      $user['hashed_pwd'] = password_hash($_POST['password'], PASSWORD_DEFAULT);
      // Create auth_code by random value and hash function
      $temp =  password_hash(strval(mt_rand()), PASSWORD_DEFAULT);
      $user['auth_code'] = str_replace(array(':', '\\', '/', '.'), 'b', $temp);

      if(strcmp($_POST['password'], $_POST['confirm_password']) !== 0){
        $this->view->render($response,'signup.twig',['error_message'=>'Two password are different']);
        return $response;
      }

      $tempaa=$this->UserModel->duplicate_check_by_email_from_user_table($user);
      // var_dump((count($tempaa)));
      if (count($this->UserModel->duplicate_check_by_email_from_user_table($user))>=1) {   //User does exist in "User" table

        $this->view->render($response,'signup.twig',['error_message'=>'E-mail address found from table.','result_code'=>1]);
        return $response;

      } else {  //User doesn't exist in "User" table
        if (count($this->UserModel->duplicate_check_by_email_from_temp_user_table($user))!=0) {
          //but User does exist in "Temp_user" table

          $this->view->render($response,'signup.twig',['error_message'=>'We have already received your sign-up request and authentication-mail has been sent. 
          Please, Check your e-mail again.','result_code'=>1]);
          return $response;


        } else {    //User doesn't exist in "User" and "Temp_user" table

          $query_results =  $this->UserModel->insert_user_into_temp_table($user);

          if($query_results){
          $mail = new PHPMailer(true);                              // Passing `true` enables exceptions
          try {
            //Server settings
            // $mail->SMTPDebug = 2;                                 // Enable verbose debug output
            $mail->isSMTP();                                      // Set mailer to use SMTP
            $mail->Host = 'smtp.gmail.com';                       // Specify main and backup SMTP servers
            $mail->SMTPAuth = true;                               // Enable SMTP authentication
            $mail->Username = 'dmsrb1595@gmail.com';                 // SMTP username
            $mail->Password = 'znjfzja1!';                           // SMTP password
            $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
            $mail->Port = 587;                                    // TCP port to connect to

            //Recipients
            $mail->setFrom('dmsrb1595@gmail.com', 'Team D');
            $mail->addAddress($user['e_mail'], 'Team D');     // Add a recipient
            $mail->isHTML(true);                                  // Set email format to HTML
            $mail->Subject = 'Authentication E-mail from "Fresh Your Route"!!';  // 메일 이름 바꾸기
            $mail->Body    = 'This is an Authentication E-mail to activate your account.
            <br>If you want to activate your acccount, Please Click the link http://teamd-iot.calit2.net/user/signin/activate/' . $user['auth_code'];
            

            $mail->send();
            $this->view->render($response,'signup.twig',['success_message'
            =>'Authentication-mail has been sent. Please check your E-mail.','result_code'=>1]);
            
            // return $response->withRedirect('/user/signin');


          } catch (Exception $e) {
          $this->view->render($response,'signup.twig',['error_message'
          =>'Authentication-mail could not be sent. Try again.']);
          return $response;

          }
          } // if insert query is true
          else{
            $this->view->render($response,'signup.twig',['error_message'
          =>'Inserting the User Information into table is failed. Try again.']);
          return $response;
          }
        }
      }
    } catch (PDOException $e) {

      $this->view->render($response,'signup.twig',['error_message'
          =>'PDOException. Try again.']);
      return $response;
      // echo ("<script LANGUAGE='JavaScript'>
      //       window.alert('PDOException.');
      //       window.location.href='http://teamd-iot.calit2.net/user/signup';
      //       </script>");

      // $json['status'] = 'error';
      // $json['message'] = 'PDOException';
      // return $response->withHeader('Content-type', 'application/json')
      // ->withStatus(400)
      // ->write(json_encode($json));
    }
  }

  
  public function account_activate(Request $request, Response $response, $args)
  {
    try {
      $url = 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
      $parts = parse_url($url);
      
      $nonce = substr($parts['path'], 22);
      
      $user_data = $this->UserModel->select_user_information_by_nonce_from_temp_table($nonce);
       
      if (count($user_data)==1) {
             $user_data[0]['permission'] = 0;
              $user_data[0]['loginStateFlag'] = 0;
              $user_data[0]['isActive'] = 1;
              $user_data[0]['auth_code'] = NULL;
      //  if nonce doese exist in temp table,
        if($this->UserModel->insert_user_into_user_table($user_data[0])){
          if($this->UserModel->delete_from_temp_user_table($nonce)) {

            $this->view->render($response,'signin.twig',['success_message'
            =>'Your account is activated.']);
            return $response;
          }
          else{
            $this->view->render($response,'signin.twig',['error_message'
            =>'Delete temp user query is failed.']);
            return $response;
          }
        
        } else {
          $this->view->render($response,'signin.twig',['error_message'
          =>'Insert User Information query is failed.']);
          return $response;
        }

      } else {
        // $this->view->render($response,'signin.twig',['error_message'
        // =>'Select user information from temp table query is failed']);
        // return $response;
     }
    } catch (PDOException $e) {
      $this->view->render($response,'signin.twig',['error_message'
      =>'PDOException error']);
      return $response;
    }
  }

  public function sign_in_request(Request $request, Response $response, $args)
  {
    $user['e_mail'] =  $_POST['e_mail'];
    $user['password'] = $_POST['password'];
    $results = $this->UserModel->select_USN_PW_from_User_table($user);
    
    if ($results) {
    
      if(password_verify($user['password'],$results['hashed_pwd'])){
        $user['USN'] = $results['USN'];
        $results['loginStateFlag'] = 1;

        if($this->UserModel->update_user_set_loginStateFlag($results)){
          $user['permission'] = $this->UserModel->select_permission_from_user_table($results);
        
            $this->view->render($response,'login_index.twig',['success_message'
            =>'Sign-In is completed','USN'=>$user['USN'],'permission'=>$user['permission']]);
            return $response;
          
        }
        else{
          $this->view->render($response,'signin.twig',['error_message'
          =>'Sign-In is Failed']);
          return $response;
        }
      }
      else{
        $this->view->render($response,'signin.twig',['error_message'
        =>'Sign-In is Failed, Password is wrong']);
        return $response;

      }
      // return $response->withHeader('Content-type', 'application/json')
      //   ->withStatus(400)
      //   ->write(json_encode($json));
    }
    else{
      $this->view->render($response,'signin.twig',['error_message'
      =>'E-mail is not found in table, Please sign-up first']);
      return $response;
    }
  }

  public function sign_out_request(Request $request, Response $response, $args)
  {
    // $this->view->render($response, 'signin.twig');
    // return $response;
    // use the passwrod_verifty to check the password
    //how do you do this
    //when someone signs in, they send email and password
    //wirte query to find account  password
    //if found, use password _verify to see if the FORM password ($_POST['password'])
    //matches the database hashed
    //if True, then set SESSION define_syslog_variables
    //such as $_SESSION['logged_in'] = 1 페이지를 이동할때마다 로그인되어있는지 확인
    //or $_SESSION['logged_in']=1
    //if FLASE, give error message
    //you might have $_SESSION['isAdmin'] = 1
  }

  public function json_test(Request $request, Response $response, $args)
  {
    $json = file_get_contents('php://input');
    $data = json_decode($json);
    echo $data->e_mail;
  }
} // end of UserController
