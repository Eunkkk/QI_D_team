<?php
namespace App\Model;

final class SensorModel extends BaseModel
{


}
