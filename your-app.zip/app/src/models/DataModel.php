<?php
namespace App\Model;

final class DataModel extends BaseModel
{
  

}
