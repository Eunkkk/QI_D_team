<?php
namespace App\Model;

final class MonitoringModel extends BaseModel
{


}
